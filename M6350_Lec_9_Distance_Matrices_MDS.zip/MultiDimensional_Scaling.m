%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%% multidimensional scaling %%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


cities = ...
{'Atl','Chi','Den','Hou','LA','Mia','NYC','SF','Sea','WDC'};
D = [    0  587 1212  701 1936  604  748 2139 2182   543;
       587    0  920  940 1745 1188  713 1858 1737   597;
      1212  920    0  879  831 1726 1631  949 1021  1494;
       701  940  879    0 1374  968 1420 1645 1891  1220;
      1936 1745  831 1374    0 2339 2451  347  959  2300;
       604 1188 1726  968 2339    0 1092 2594 2734   923;
       748  713 1631 1420 2451 1092    0 2571 2408   205;
      2139 1858  949 1645  347 2594 2571    0  678  2442;
      2182 1737 1021 1891  959 2734 2408  678    0  2329;
       543  597 1494 1220 2300  923  205 2442 2329     0];

%%%%%%%%%%%%%%%%%


[Y,eigvals] = cmdscale(D);

%
% Y = cmdscale(D) takes an n-by-n distance matrix D, and returns an n-by-p configuration matrix Y. 
% Rows of Y are the coordinates of n points in p-dimensional space for some p < n. 
% When D is a Euclidean distance matrix, the distances between those points are given by D. 
% p is the dimension of the smallest space in which the n points whose inter-point distances 
% are given by D can be embedded.

% [Y,e] = cmdscale(D) also returns the eigenvalues of Y*Y'. 
% When D is Euclidean, the first p elements of e are positive, the rest zero. 
% If the first k elements of e are much larger than the remaining (n-k), 
% then you can use the first k columns of Y as k-dimensional points whose 
% inter-point distances approximate D. 

% [Y,e] = cmdscale(D,p) also accepts a positive integer p between 1 and n. 
% p specifies the dimensionality of the desired embedding Y. 
% If a p dimensional embedding is possible, then Y will be of size n-by-p and e 
% will be of size p-by-1. If only a q dimensional embedding with q < p is possible, 
% then Y will be of size n-by-q and e will be of size p-by-1. 
% Specifying p may reduce the computational burden when n is very large.

format short g
[eigvals eigvals/max(abs(eigvals))]

% The eigenvalues are returned by cmdscale -- Some of these are negative, indicating that the original 
% distances are not Euclidean. This is because of the curvature of the earth.

% the two largest positive eigenvalues are much larger in magnitude than 
% the remaining eigenvalues. So, despite the negative eigenvalues, the first 
% two coordinates of Y are sufficient for a reasonable reproduction of D.

plot(Y(:,1),Y(:,2),'.')
text(Y(:,1)+25,Y(:,2),cities)
xlabel('Miles')
ylabel('Miles')

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%  Nonclassical multidimensional scaling %%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


clear 

% Y = mdscale(D,p) performs nonmetric multidimensional scaling on 
% the n-by-n dissimilarity matrix D, and returns Y, a configuration of n points (rows) 
% in p dimensions (columns). The Euclidean distances between points in Y approximate 
% a monotonic transformation of the corresponding dissimilarities in D.


load cereal.mat

X = [Calories Protein Fat Sodium Fiber ...
     Carbo Sugars Shelf Potass Vitamins];

% Take a subset from a single manufacturer.
X = X(strcmp('K',cellstr(Mfg)),:);


% Create a dissimilarity matrix.

dissimilarities = pdist(X);

% Use non-metric scaling to recreate the data in 2D,
% and make a Shepard plot of the results.

[Y,stress,disparities] = mdscale(dissimilarities,2);
distances = pdist(Y);

[dum,ord] = sortrows([disparities(:) dissimilarities(:)]);

plot(dissimilarities,distances,'bo', ...
dissimilarities(ord),disparities(ord),'r.-');
xlabel('Dissimilarities'); ylabel('Distances/Disparities')
legend({'Distances' 'Disparities'},'Location','NW');


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%  Procrustes Analysis  %%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% d = procrustes(X,Y) determines a linear transformation 
% (translation, reflection, orthogonal rotation, and scaling) 
% of the points in matrix Y to best conform them to the points in matrix X. 
% The goodness-of-fit criterion is the sum of squared errors. 
% procrustes returns the minimized value of this dissimilarity measure in d.


rng('default')
n = 10;  
X = normrnd(0,1,[n 2]);

% Rotate, scale, translate, and add some noise to sample points. 

S = [0.5 -sqrt(3)/2; sqrt(3)/2 0.5];
Y = normrnd(0.5*X*S+2,0.05,n,2);

% Conform Y to X using procrustes analysis.

[d,Z,tr] = procrustes(X,Y);

% Plot the original X and Y with the transformed Y .

plot(X(:,1),X(:,2),'rx',Y(:,1),Y(:,2),'b.',Z(:,1),Z(:,2),'bx');


