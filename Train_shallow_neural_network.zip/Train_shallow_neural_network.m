%% Train shallow neural network

% Here input x and targets t define a simple function that you can plot:

x = [0 1 2 3 4 5 6 7 8];
t = [0 0.84 0.91 0.14 -0.77 -0.96 -0.28 0.66 0.99];
plot(x,t,'o')

% Here feedforwardnet creates a 
%% two-layer feed-forward network. 
%The network has 
%% one hidden layer with ten neurons.

net = feedforwardnet(10);
net = configure(net,x,t);
y1 = net(x)
plot(x,t,'o',x,y1,'x')

% The network is trained and then resimulated.

net = train(net,x,t);
y2 = net(x)
plot(x,t,'o',x,y1,'x',x,y2,'*')

%% Train NARX (Nonlinear AutoRegressive with eXternal input) Time Series Network 

%  an open-loop nonlinear-autoregressive network with external input, to model a levitated magnet 
% system defined by a control current x and the magnet�s vertical position response t, 
% then simulates the network. 

[x,t] = maglev_dataset;
net = narxnet(10);
[xo,xi,~,to] = preparets(net,x,{},t);
net = train(net,xo,to,xi);
y = net(xo,xi)

% The function "preparets" prepares the data before training and simulation. It creates the open-loop network�s 
% combined inputs xo, which contains both the external input x and previous values of position t. 
% It also prepares the delay states xi.

 
