%%%%%  TREES / DENDROGRAMS %%%%%%%%%%%%%%%%%%%%

% D = pdist(X) returns the Euclidean distance between pairs of observations in X. 
% D = pdist(X,Distance) returns the distance by using the method specified by Distance. 

% Create a matrix with three observations and two variables.

rng('default') % initiating the random number generator

X = rand(10,3); % Create a matrix with 10 observations of 3 variables.

D = pdist(X);  % returns the Euclidean distance between pairs of observations

Z = squareform(D); % locate the distance between observations i and j in the form of a distance matrix


%%%%%%%%%  linkage -- Agglomerative hierarchical cluster tree %%%

%% R = linkage(X) returns a matrix that encodes a tree of hierarchical clusters 
%% of the rows of the real matrix X.

tree = linkage(X,'average');

%%   Method	Description

%%  'average'	Unweighted average distance (UPGMA)

%%  'centroid'	Centroid distance (UPGMC), appropriate for Euclidean distances only

%%  'complete'  Furthest distance 

%%   'median'   Weighted center of mass distance (WPGMC), appropriate for Euclidean distances only

%%   'single' Shortest distance

%%   'ward'   Inner squared distance (minimum variance algorithm),  Euclidean distances only

%%% dendrogram(Z)  % Draw a dendrogram 

H = dendrogram(tree,'Orientation','left','ColorThreshold','default');
set(H,'LineWidth',2)


%%%%%%  THE SHORTEST PATH PROBLEM %%%%%%%%%%%%%%

clear

load oscillatorgraph  %% g, a sparse matrix, and names, a list of the names of the nodes of the graph.

spy(g) %% The spy function displays as * wherever there is a non-zero element of the matrix.

gObj = biograph(g,names) %%% Biograph object with 65 nodes and 123 edges.

gObj = view(gObj);


% find the nodes pA, pB, and pC  -  three repression proteins %%%%%%%%
pANode = find(strcmp('pA', names));
pBNode = find(strcmp('pB',names));
pCNode = find(strcmp('pC', names));

% Color these red, green, and blue
gObj.nodes(pANode).Color = [1 0 0];
gObj.nodes(pANode).Size = [40 30];
gObj.nodes(pBNode).Color = [0 1 0];
gObj.nodes(pBNode).Size = [40 30];
gObj.nodes(pCNode).Color = [0 0 1];
gObj.nodes(pCNode).Size = [40 30];
dolayout(gObj);

%%%%%% Finding the Shortest Path Between Nodes pA and pC

[dist,path,pred] = shortestpath(gObj,pANode,pCNode);

%%%%  Color the nodes and edges of the shortest path 

set(gObj.Nodes(path),'Color',[1 0.4 0.4])
edges = getedgesbynodeid(gObj,get(gObj.Nodes(path),'ID'));
set(edges,'LineColor',[1 0 0])
set(edges,'LineWidth',1.5)


%%%% finding an efficient way to traverse a graph by moving between adjacent nodes

order = traverse(gObj,pANode); shows the order in which the nodes were traversed starting at pA.

%%%% find an alternative path from pA to pC. 

alternatePath = order(1:find(order == pCNode));
set(gObj.Nodes(alternatePath),'Color',[0.4 0.4 1])
edges = getedgesbynodeid(gObj,get(gObj.Nodes(alternatePath),'ID'));
set(edges,'LineColor',[0 0 1])
set(edges,'LineWidth',1.5)

%%%%  calculate the shortest paths from each node to all other nodes

allShortest = allshortestpaths(gObj);

%%%%  A heatmap of these distances 

imagesc(allShortest)
colormap(pink);
colorbar
title('All Shortest Paths for Oscillator Model');

%%%%  construct a dendrogram 

tree = linkage(allShortest,'average')

H = dendrogram(tree,'Orientation','left','ColorThreshold','default');
set(H,'LineWidth',2)


