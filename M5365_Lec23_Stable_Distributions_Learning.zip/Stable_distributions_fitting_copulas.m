%%%%%%%%%%%%%  Stable distribtuions in matlab %%%%%%%%%%%%%%

pd1 = makedist('Stable','alpha',2,'beta',0,'gam',1,'delta',0);
pd2 = makedist('Stable','alpha',1,'beta',0,'gam',1,'delta',0);
pd3 = makedist('Stable','alpha',0.5,'beta',0,'gam',1,'delta',0);


%% Calculate the pdf for each distribution. 

x = -5:.1:5;
pdf1 = pdf(pd1,x);
pdf2 = pdf(pd2,x);
pdf3 = pdf(pd3,x);

%%% Plot all three pdf functions on the same figure for visual comparison.

figure
plot(x,pdf1,'b-');
hold on
plot(x,pdf2,'r-.');
plot(x,pdf3,'k--');
title('Compare Alpha Parameters in Stable Distribution PDF Plots')
legend('\alpha = 2','\alpha = 1','\alpha = 0.5','Location','northwest')
hold off


%% The next plot compares the probability density functions for 
%% stable distributions with different beta values. 
%% In each case, alpha = 0.5, gam = 1, and delta = 0.

pd1 = makedist('Stable','alpha',0.5,'beta',0,'gam',1,'delta',0);
pd2 = makedist('Stable','alpha',0.5,'beta',0.5,'gam',1,'delta',0);
pd3 = makedist('Stable','alpha',0.5,'beta',1,'gam',1,'delta',0);


%% Calculate the pdf for each distribution.

x = -5:.1:5;
pdf1 = pdf(pd1,x);
pdf2 = pdf(pd2,x);
pdf3 = pdf(pd3,x);

%% Plot all three pdf functions on the same figure for visual comparison.

figure
plot(x,pdf1,'b-');
hold on
plot(x,pdf2,'r-.');
plot(x,pdf3,'k--');
title('Compare Beta Parameters in Stable Distribution PDF Plots')
legend('\beta = 0','\beta = 0.5','\beta = 1','Location','northwest')
hold off

%% Create a probability distribution object for 
%%  the standard normal, Cauchy, and L�vy distributions.

pd_norm = makedist('Stable','alpha',2,'beta',0,'gam',1/sqrt(2),'delta',0);
pd_cauchy = makedist('Stable','alpha',1,'beta',0,'gam',1,'delta',0);
pd_levy = makedist('Stable','alpha',0.5,'beta',1,'gam',1,'delta',0);

%% Calculate the pdf for each distribution.

x = -5:.1:5;
pdf_norm = pdf(pd_norm,x);
pdf_cauchy = pdf(pd_cauchy,x);
pdf_levy = pdf(pd_levy,x);

%% Plot all three pdf functions on the same figure for visual comparison.


figure
plot(x,pdf_norm,'b-');
hold on
plot(x,pdf_cauchy,'r.');
plot(x,pdf_levy,'k--');
title('Compare Stable Distributions pdf Plots')
legend('Normal','Cauchy','Levy','Location','northwest')
hold off


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%% Fit probability distribution object to data %%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% pd = fitdist(x,distname) 
% creates a probability distribution object by fitting the distribution 
% specified by distname to the data in column vector x.

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%  Fit a Normal Distribution to Data
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
clear 

load hospital % look up 
x = hospital.Weight;

% Create a normal distribution object by fitting it to the data. 

pd = fitdist(x,'Normal')

% The intervals next to the parameter estimates are the 95% confidence intervals 

% for the distribution parameters. Plot the pdf of the distribution. 

x_values = 50:1:250;
y = pdf(pd,x_values);
plot(x_values,y,'LineWidth',2)

%%%%%%% Fit a Kernel Distribution to Data
%% Create a kernel distribution object by fitting it to the data. Use the Epanechnikov kernel function. 

pd = fitdist(x,'Kernel','Kernel','epanechnikov')

x_values = 50:1:250;
y = pdf(pd,x_values);
plot(x_values,y)

%% Fit Normal Distributions to Grouped Data

gender = hospital.Sex;
[pdca,gn,gl] = fitdist(x,'Normal','By',gender)

% The cell array pdca contains two  probability distribution objects, 
% one for each gender group. The cell array gn contains two group labels. 
% The cell array gl contains two group levels.

female = pdca{1}  % Distribution for females

male = pdca{2}  % Distribution for males

%% Compute the pdf of each distribution.  

x_values = 50:1:250;
femalepdf = pdf(female,x_values);
malepdf = pdf(male,x_values);

%% Plot the pdfs for a visual comparison of weight distribution by gender. 

figure
plot(x_values,femalepdf,'LineWidth',2)
hold on
plot(x_values,malepdf,'Color','r','LineStyle',':','LineWidth',2)
legend(gn,'Location','NorthEast')
hold off

%%% Fit Kernel Distributions to Grouped Data

% Create kernel distribution objects by fitting them to the data, 
% grouped by patient gender. Use a triangular kernel function.

gender = hospital.Sex;
[pdca,gn,gl] = fitdist(x,'Kernel','By',gender,'Kernel','triangle');


female = pdca{1}  % Distribution for females
male = pdca{2}  % Distribution for males

%% Compute the pdf of each distribution. 
x_values = 50:1:250;
femalepdf = pdf(female,x_values);
malepdf = pdf(male,x_values);

%% Plot 

figure
plot(x_values,femalepdf,'LineWidth',2)
hold on
plot(x_values,malepdf,'Color','r','LineStyle',':','LineWidth',2)
legend(gn,'Location','NorthEast')
hold off

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Distribution Name	Description	Distribution Object
% 'Beta'	Beta distribution	BetaDistribution
% 'Binomial'	Binomial distribution	BinomialDistribution
%'BirnbaumSaunders'	Birnbaum-Saunders distribution	BirnbaumSaundersDistribution
%'Burr'	Burr distribution	BurrDistribution
%'Exponential'	Exponential distribution	ExponentialDistribution
%'ExtremeValue'	Extreme Value distribution	ExtremeValueDistribution
%'Gamma'	Gamma distribution	GammaDistribution
%'GeneralizedExtremeValue'	Generalized Extreme Value distribution	GeneralizedExtremeValueDistribution
%'GeneralizedPareto'	Generalized Pareto distribution	GeneralizedParetoDistribution
%'HalfNormal'	Half-normal distribution	HalfNormalDistribution
%'InverseGaussian'	Inverse Gaussian distribution	InverseGaussianDistribution
%'Kernel'	Kernel distribution	KernelDistribution
%'Logistic'	Logistic distribution	LogisticDistribution
%'Loglogistic'	Loglogistic distribution	LoglogisticDistribution
%'Lognormal'	Lognormal distribution	LognormalDistribution
%'Nakagami'	Nakagami distribution	NakagamiDistribution
%'NegativeBinomial'	Negative Binomial distribution	NegativeBinomialDistribution
%'Normal'	Normal distribution	NormalDistribution
%'Poisson'	Poisson distribution	PoissonDistribution
%'Rayleigh'	Rayleigh distribution	RayleighDistribution
%'Rician'	Rician distribution	RicianDistribution
%'Stable'	Stable distribution	StableDistribution
%'tLocationScale'	t Location-Scale distribution	tLocationScaleDistribution
%'Weibull'	Weibull distribution	WeibullDistribution

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%% Copula Distributions and Correlated Samples %%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% Copulas are functions that describe dependencies among variables, 
%% and provide a way to create distributions that model correlated
% multivariate data. a copula is a multivariate cumulative distribution 
%% function for which the marginal probability distribution of each variable 
%% is uniform. 

%%% Copula Distributions and Correlated Samples %%%%%%%%%%%%%%%%%%%%%%%%

%% Fit a t Copula to Data

clear

load stockreturns
x = stocks(:,1);
y = stocks(:,2);

figure;
scatterhist(x,y)

%%  Transform the data to the copula scale (unit square) 
%%  using a kernel estimator of the cumulative distribution function.

u = ksdensity(x,x,'function','cdf');
v = ksdensity(y,y,'function','cdf');

figure;
scatterhist(u,v)
xlabel('u')
ylabel('v')

%% Fit a t copula to the data. 

rng default  % For reproducibility
[Rho,nu] = copulafit('t',[u v],'Method','ApproximateML')

%% Generate a random sample from the t copula.

r = copularnd('t',Rho,nu,1000);
u1 = r(:,1);
v1 = r(:,2);

figure;
scatterhist(u1,v1)
xlabel('u')
ylabel('v')
set(get(gca,'children'),'marker','.')

% Transform the random sample back to the original scale of the data.

x1 = ksdensity(x,u1,'function','icdf');
y1 = ksdensity(y,v1,'function','icdf');

figure;
scatterhist(x1,y1)
set(get(gca,'children'),'marker','.')

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Compute the Gaussian Copula Rank Correlation
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

rho = -.7071;
tau = copulastat('gaussian',rho)

% Use the copula to generate dependent random values from a beta distribution that has parameters a and b equal to 2. 

rng default  % For reproducibility
u = copularnd('gaussian',rho,100);
b = betainv(u,2,2);

% Verify that the sample has a rank correlation approximately equal to tau.

tau_sample = corr(b,'type','k')




