clear

%%%% Multivariate distribution - 2d %%%%%%%%%%

mu = [0 0];
Sigma = [.25 .3; .3 1];
x1 = -3:.2:3; x2 = -3:.2:3;
[X1,X2] = meshgrid(x1,x2);
F = mvnpdf([X1(:) X2(:)],mu,Sigma);
F = reshape(F,length(x2),length(x1));
surf(x1,x2,F);
caxis([min(F(:))-.5*range(F(:)),max(F(:))]);
axis([-3 3 -3 3 0 .4]) 
xlabel('x1'); ylabel('x2'); zlabel('Probability Density');

%%%%%%%%%%%%%%

clear


%%%%%%%

MU=zeros(500);

A = rand(500,500); % generate a random 500 x 500 matrix

% construct a symmetric matrix using 

A = rand(500,500);
SIGMA=(A*A')/norm(A*A');

r = mvnrnd(MU,SIGMA,500);

for i = 1:1000
    R(i)=norm(mvnrnd(MU,SIGMA,500)-mvnrnd(MU,SIGMA,500));
end

histogram(R)

%%%%

r = mvnrnd(MU,SIGMA,500);
r1 = mvnrnd(MU,SIGMA,500);
X=r*r1';
Y=r*r1';