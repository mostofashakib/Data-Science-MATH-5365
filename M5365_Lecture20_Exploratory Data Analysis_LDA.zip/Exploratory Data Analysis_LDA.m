%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Visualizing Multivariate Data %%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

load fisheriris
gscatter(meas(:,1), meas(:,2), species,'rgb','osd');
xlabel('Sepal length');
ylabel('Sepal width');
N = size(meas,1);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


plotmatrix(meas)

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%% Linear Discriminant Analysis

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

lda = fitcdiscr(meas(:,1:2),species);
ldaClass = resubPredict(lda);

%%% Compute the resubstitution error, 
%%  which is the misclassification error 
%%  (the proportion of misclassified observations) 
%%  on the training set.

ldaResubErr = resubLoss(lda)

%% You can also compute the confusion matrix on the training set. 

[ldaResubCM,grpOrder] = confusionmat(species,ldaClass)

%% 20% or 30 observations are misclassified by the linear discriminant function. 

bad = ~strcmp(ldaClass,species);
hold on;
plot(meas(bad,1), meas(bad,2), 'kx');
hold off;

%% The function has separated the plane into regions 
%% divided by lines, and assigned different regions 
%% to different species. 

[x,y] = meshgrid(4:.1:8,2:.1:4.5);
x = x(:);
y = y(:);
j = classify([x y],meas(:,1:2),species);
gscatter(x,y,j,'grb','sod')

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%  Quadratic Discriminant Analysis
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%% For some data sets, the regions for the various classes are not well separated by %% lines. When that is the case, linear discriminant analysis is not appropriate. 
%% Instead, you can try quadratic discriminant analysis (QDA) for our data.


qda = fitcdiscr(meas(:,1:2),species,'DiscrimType','quadratic');

%% A stratified 10-fold cross-validation is a popular choice 
%% for estimating the test error on classification algorithms. 
%% It randomly divides the training set into 10 disjoint subsets. 
%% Each subset has roughly equal size and roughly the same class 
%% proportions as in the training set.


%% First use cvpartition to generate 10 disjoint stratified subsets.
%% c = cvpartition(n,'KFold',k) constructs an object 'c' of the cvpartition class %% defining a random nonstratified partition for k-fold cross-validation on n %% observations. The partition divides the observations into 'k' disjoint subsamples %% (or folds), chosen randomly but with roughly equal size. 
%% The default value of k is 10.

rng(0,'twister');
cp = cvpartition(species,'KFold',10)

%% The crossval and kfoldLoss methods can estimate 
%% the misclassification error for both LDA and QDA 
%% using the given data partition cp.

%% Estimate the true test error for LDA using 
%% 10-fold stratified cross-validation.


cvlda = crossval(lda,'CVPartition',cp);
ldaCVErr = kfoldLoss(cvlda)

%%%% plotting %% 

qdaClass = resubPredict(qda);
bad = ~strcmp(qdaClass,species);
hold on;
plot(meas(bad,1), meas(bad,2), 'kx');
hold off;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%  Visualizing Multivariate Data
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

load carbig

X = [MPG,Acceleration,Displacement,Weight,Horsepower];
varNames = {'MPG'; 'Acceleration'; 'Displacement'; 'Weight'; 'Horsepower'};

%%% Viewing slices through lower dimensional subspaces 
%% The points in each scatterplot are color-coded by the number 
%% of cylinders: blue for 4 cylinders, green for 6, and red for 8. 


figure
gplotmatrix(X,[],Cylinders,['c' 'b' 'm' 'g' 'r'],[],[],false);
text([.08 .24 .43 .66 .83], repmat(-.1,1,5), varNames, 'FontSize',8);
text(repmat(-.12,1,5), [.86 .62 .41 .25 .02], varNames, 'FontSize',8, 'Rotation',90);

%%%%%%%%%%%%%%%%%%%%%%%%%
%%% Parallel Coordinates Plots
%%%%%%%%%%%%%%%%%%%%%%%


%%  In this plot, the coordinate axes are all laid out horizontally, 
%% instead of using orthogonal axes as in the usual Cartesian graph.
%%  Each observation is represented in the plot as a series of connected 
%% line segments. For example, we can make a plot of all the cars with 
%%  4, 6, or 8 cylinders, and color observations by group. 

Cyl468 = ismember(Cylinders,[4 6 8]);
parallelcoords(X(Cyl468,:), 'group',Cylinders(Cyl468), ...
               'standardize','on', 'labels',varNames)

%% Because the five variables have widely different ranges, 
%% this plot was made with standardized values, where each variable 
%% has been standardized to have zero mean and unit variance.

%% With the color coding, the graph shows, 
%% for example, that 8 cylinder cars typically have 
%% low values for MPG and acceleration, and high values for displacement, 
%% weight, and horsepower.



%%  We can also make a parallel coordinates plot where only 
%% the median and quartiles (25% and 75% points) for each group are shown. 


parallelcoords(X(Cyl468,:), 'group',Cylinders(Cyl468), ...
               'standardize','on', 'labels',varNames, 'quantile',.25)

%%%%%%%%%%%%%%%%%%%%%%%%
%% Andrews Plots
%%%%%%%%%%%%%%%%%%%%%%%% 

andrewsplot(X(Cyl468,:), 'group',Cylinders(Cyl468), 'standardize','on')


%% Each function is a Fourier series, with coefficients equal to the corresponding %% observation's values. In this example, the series has five terms: a constant, two %% sine terms with periods 1 and 1/2, and two similar cosine terms.


%%%%%%%%%%%%%%%%%%%%%%%%
%% Glyph Plots
%%%%%%%%%%%%%%%%%%%%%%%% 

h = glyphplot(X(1:9,:), 'glyph','star', 'varLabels',varNames, 'obslabels',Model(1:9,:));
set(h(:,3),'FontSize',8);

%% here is a star plot of the first 9 models in the car data. 
%% Each spoke in a star represents one variable, 
%% and the spoke length is proportional to the value of that variable 
%% for that observation.

h = glyphplot(X(1:9,:), 'glyph','face', 'varLabels',varNames, 'obslabels',Model(1:9,:));
set(h(:,3),'FontSize',8);


%% Another type of glyph is the Chernoff face. 
%% This glyph encodes the data values for each 
%% observation into facial features, such as the size 
%% of the face, the shape of the face, position of the eyes, etc.


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Glyph Plots and Multidimensional Scaling
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%% First select all cars from 1977, 
%% and use the zscore function to standardize each of the five variables 
%% to have zero mean and unit variance. Then we'll compute the Euclidean 
%% distances among those standardized observations as a measure of dissimilarity.

models77 = find((Model_Year==77));
dissimilarity = pdist(zscore(X(models77,:)));

%% We use mdscale to create a set of locations in two dimensions 
%% whose interpoint distances approximate the dissimilarities among 
%% the original high-dimensional data, and plot the glyphs using 
%% those locations.

Y = mdscale(dissimilarity,2);
glyphplot(X(models77,:), 'glyph','star', 'centers',Y, ...
          'varLabels',varNames, 'obslabels',Model(models77,:), 'radius',.5);
title('1977 Model Year');

%% In this plot, we've used MDS as dimension reduction method, 
%% to create a 2D plot. Normally that would mean a loss of information, 
%% but by plotting the glyphs, we have incorporated all of the high-dimensional 
%% information in the data.');

glyphplot(X(models77,:), 'glyph','face', 'centers',Y, ...
          'varLabels',varNames, 'obslabels',Model(models77,:));
title('1977 Model Year');

