%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%  Time-Frequency Analysis of Modulated Signals %%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


%% Load a quadratic chirp signal and plot its spectrogram. 
%% The signal's frequency begins at approximately 500 Hz at t = 0, 
%% decreases to 100 Hz at t=2, and increases back to 500 Hz at t=4. 
%% The sampling frequency is 1 kHz.

%% the STFT: 


load quadchirp;
fs = 1000;
[S,F,T] = spectrogram(quadchirp,100,98,128,fs);
helperCWTTimeFreqPlot(S,T,F,'surf','STFT of Quadratic Chirp','Seconds','Hz')


%%  Obtain a time-frequency plot of this signal using the continuous wavelet 
%%  transform (CWT) with a bump wavelet.
%% The CWT clearly shows the time evolution of the quadratic chirp's frequency.


[cfs,f] = cwt(quadchirp,'bump',fs);
helperCWTTimeFreqPlot(cfs,tquad,f,'surf','CWT of Quadratic Chirp','Seconds','Hz')

%%% Obtain and plot the CWT for the bat data 


load batsignal
t = 0:DT:(numel(batsignal)*DT)-DT;
[cfs,f] = cwt(batsignal,'bump',1/DT,'VoicesPerOctave',32);
helperCWTTimeFreqPlot(cfs,t.*1e6,f./1e3,'surf','Bat Echolocation (CWT)',...
    'Microseconds','kHz')


%%% Obtain and plot  the STFT of the bat data.


[S,F,T] = spectrogram(batsignal,50,48,128,1/DT);
helperCWTTimeFreqPlot(S,T.*1e6,F./1e3,'surf','Bat Echolocation (STFT)',...
    'Microseconds','kHz')

%% the 1995 Kobe earthquake

load kobe;
dt = 1;
cwt(kobe,1);
title('CWT of 1995 Kobe Earthquake Seismograph Data');

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%  Time-Frequency Analysis with Wavelet Packets %%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%% consider two intermittent sine waves with frequencies of 150 and 200 Hz in 
%%  additive noise. The data are sampled at 1 kHz. To prevent the loss of time 
%% resolution inherent in the critically-sampled wavelet packet transform, use the 
%% undecimated transform.


dt = 0.001;
t = 0:dt:1-dt;
x = ...
cos(2*pi*150*t).*(t>=0.2 & t<0.4)+sin(2*pi*200*t).*(t>0.6 & t<0.9);
y = x+0.05*randn(size(t));
[wpt,~,F] = modwpt(x,'TimeAlign',true);
contour(t,F.*(1/dt),abs(wpt).^2)
grid on
xlabel('Time (secs)')
ylabel('Hz')
title('Time-Frequency Analysis -- Undecimated Wavelet Packet Transform')

%% the wavelet packet transform is able to separate the 150 and 200 Hz components. 


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Time-Varying Coherence   %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
 
%% Because wavelets provide local information about data in time and scale
%% (frequency), wavelet-based coherence allows you to measure time-varying 
%% correlation as a function of frequency. In other words, a coherence measure 
%% suitable for nonstationary processes.

%% near-infrared spectroscopy (NIRS) data obtained in two human subjects. NIRS 
%% measures brain activity by exploiting the different absorption characteristics of 
%% oxygenated and deoxygenated hemoglobin. The recording site was the superior 
%% frontal cortex for both subjects and the data was sampled at 10 Hz.

load NIRSData;
figure
plot(tm,NIRSData(:,1))
hold on
plot(tm,NIRSData(:,2),'r')
legend('Subject 1','Subject 2','Location','NorthWest')
xlabel('Seconds')
title('NIRS Data')
grid on;
hold off;

%% Examining the time-domain data, it is not clear what oscillations are present in 
%% the individual time series, or what oscillations are common to both data sets. 


%% Obtain the wavelet coherence as a function of time and frequency. You can use 
%% wcoherence to output the wavelet coherence, cross-spectrum, scale-to- frequency, 
%% or scale-to-period conversions, as well as the cone of influence. In this example, 
%% the helper function helperPlotCoherence packages some useful commands for plotting 
%% the outputs of wcoherence.

[wcoh,~,f,coi] = wcoherence(NIRSData(:,1),NIRSData(:,2),10,'numscales',16);
helperPlotCoherence(wcoh,tm,f,coi,'Seconds','Hz');


%% a region of strong coherence throughout the data collection period around 1 Hz. 
%% This results from the cardiac rhythms of the two subjects. 

%% the wavelet coherence in terms of periods 

[wcoh,~,P,coi] = wcoherence(NIRSData(:,1),NIRSData(:,2),1/10,'dt',...
    'numscales',16);
helperPlotCoherence(wcoh,tm,P,coi,'Time (secs)','Periods (Seconds)');

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Wavelet Denoising  %%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%% create a noisy "bumps" signal.

rng default;
[X,XN] = wnoise('bumps',10,sqrt(6));
subplot(211)
plot(X); title('Original Signal');
AX = gca;
AX.YLim = [0 12];
subplot(212)
plot(XN); title('Noisy Signal');
AX = gca;
AX.YLim = [0 12];


%% Denoise the signal down to level 4 using the wavelet transform. 

xdMODWT = wden(XN,'modwtsqtwolog','s','mln',4,'sym4');
figure;
plot(X,'r')
hold on;
plot(xdMODWT)
legend('Denoised Signal','Original Signal','Location','NorthEastOutside')
axis tight;
hold off;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%% use wavelets to denoise images %%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

load(fullfile(matlabroot,'examples','wavelet', 'jump.mat'));
wname = 'bior3.5';
level = 5;
[C,S] = wavedec2(jump,level,wname);
imagesc(jump);

%% Wavelets are able to remove noise while preserving the perceptually important features.

thr = wthrmngr('dw2ddenoLVL','penalhi',C,S,3);
sorh = 's';
[XDEN,cfsDEN,dimCFS] = wdencmp('lvd',C,S,wname,level,thr,sorh);

figure;
subplot(1,2,1);
imagesc(jump); colormap gray; axis off;
title('Noisy Image');
subplot(1,2,2);
imagesc(XDEN); colormap gray; axis off;
title('Denoised Image');

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% 
%%% Multiscale Principal Components Analysis
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%% The aim of multiscale PCA is to reconstruct 
%% a simplified multivariate signal, starting from 
%% a multivariate signal and using a simple representation 
%% at each resolution level. Multiscale principal components 
%% analysis generalizes the PCA of a multivariate signal 
%% represented as a matrix by simultaneously performing a PCA 
%% on the matrices of details of different levels. 

 load ex4mwden
 whos

%% Usually, only the matrix of data x is available. 
%% Here, we also have the true noise covariance matrix covar 
%% and the original signals x_orig. These signals are noisy 
%% versions of simple combinations of the two original signals. 

kp = 0;
for i = 1:4 
    subplot(4,2,kp+1), plot(x (:,i)); axis tight; 
    title(['Original signal ',num2str(i)])
        kp = kp + 2;
end


%% Multiscale PCA combines noncentered PCA on approximations 
%% and details in the wavelet domain and a final PCA. 
%% At each level, the most significant principal components are selected.


level = 5;
wname = 'sym4';



%% automatically select the number of retained principal 
%% components using Kaiser's rule, which retains components 
%% associated with eigenvalues exceeding the mean of all 
%% eigenvalues:

npc = 'kais';

%% Perform multiscale PCA:

[x_sim, qual, npc] = wmspca(x ,level, wname, npc);

%% Display the Original and Simplified Signals

kp = 0;
for i = 1:4 
    subplot(4,2,kp+1), plot(x (:,i)); axis tight; 
    title(['Original signal ',num2str(i)])
    subplot(4,2,kp+2), plot(x_sim(:,i)); axis tight;
    title(['Simplified signal ',num2str(i)])
    kp = kp + 2;
end


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Compression by Global Thresholding  %%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


load mask       
image(X)
axis square
colormap(pink(255))
title('Original Image: mask')

%% A measure of achieved compression is given by the compression ratio
%%  (CR) and the Bit-Per-Pixel (BPP) ratio. CR and BPP represent equivalent 
%% information. CR indicates that the compressed image is stored using CR % of the 
%% initial storage size while BPP is the number of bits used to store one pixel of 
%% the image. For a grayscale image the initial BPP is 8. For a truecolor image the 
%% initial BPP is 24, because 8 bits are used to encode each of the three colors
%%  (RGB color space).

%% the method of cascading global coefficients thresholding 

meth   = 'gbl_mmc_h'; % Method name
option = 'c';         % 'c' stands for compression
[CR,BPP] = wcompress(option,X,'mask.wtc',meth,'BPP',0.5)

%% Uncompression

option = 'u';  % 'u' stands for uncompression
Xc = wcompress(option,'mask.wtc');
colormap(pink(255))
subplot(1,2,1); image(X);
axis square;
title('Original Image')
subplot(1,2,2); image(Xc);
axis square;
title('Compressed Image')
xlabel({['Compression Ratio: ' num2str(CR,'%1.2f %%')], ...
        ['BPP: ' num2str(BPP,'%3.2f')]})


%%%%%%%%%%%%%%%%%%%%%%%%
%%% Compression by Progressive Methods
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


meth   = 'ezw';   % Method name
wname  = 'haar';  % Wavelet name
nbloop = 6;       % Number of loops
[CR,BPP] = wcompress('c',X,'mask.wtc',meth,'maxloop', nbloop, ...
                     'wname','haar');
Xc = wcompress('u','mask.wtc');
colormap(pink(255))
subplot(1,2,1); image(X);
axis square;
title('Original Image')
subplot(1,2,2); image(Xc);
axis square;
title('Compressed Image - 6 steps')
xlabel({['Compression Ratio: ' num2str(CR,'%1.2f %%')], ...
        ['BPP: ' num2str(BPP,'%3.2f')]})


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%  Handling Truecolor Images %%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

X = imread('wpeppers.jpg');
[CR,BPP] = wcompress('c',X,'wpeppers.wtc','spiht','maxloop',12);
Xc = wcompress('u','wpeppers.wtc');
colormap(pink(255))
subplot(1,2,1); image(X);
axis square;
title('Original Image')
subplot(1,2,2); image(Xc);
axis square;
title('Compressed Image - 12 steps')
xlabel({['Compression Ratio: ' num2str(CR,'%1.2f %%')], ...
        ['BPP: ' num2str(BPP,'%3.2f')]})




