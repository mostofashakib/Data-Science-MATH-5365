%% Visualize Activations of LSTM Network %%%%%%%%%%%%%%%%%%%%%%%
% JapaneseVowelsNet is a pretrained LSTM network trained 
% [1] M. Kudo, J. Toyama, and M. Shimbo. "Multidimensional Curve Classification Using Passing-Through Regions." 
% Pattern Recognition Letters. Vol. 20, No. 11�13, pages 1103�1111.on the Japanese Vowels dataset as described 


load JapaneseVowelsNet

% View the network architecture.

net.Layers

[XTest,YTest] = japaneseVowelsTestData;

% Visualize the first time series in a plot. Each line corresponds to a feature.


X = XTest{1};

figure
plot(XTest{1}')
xlabel("Time Step")
title("Test Observation 1")
numFeatures = size(XTest{1},1);
legend("Feature " + string(1:numFeatures),'Location','northeastoutside')

% For each time step of the sequences, get the activations output by the LSTM layer (layer 2) 
% for that time step and update the network state.

sequenceLength = size(X,2);
idxLayer = 2;
outputSize = net.Layers(idxLayer).NumHiddenUnits;

for i = 1:sequenceLength
    features(:,i) = activations(net,X(:,i),idxLayer);
    [net, YPred(i)] = classifyAndUpdateState(net,X(:,i));
end

% Visualize the first 10 hidden units using a heatmap.

figure
heatmap(features(1:10,:));
xlabel("Time Step")
ylabel("Hidden Unit")
title("LSTM Activations")

% The heatmap shows how strongly each hidden unit activates and highlights
% how the activations change over time. 