%%%%%  TREES / DENDROGRAMS %%%%%%%%%%%%%%%%%%%%

% D = pdist(X) returns the Euclidean distance between pairs of observations in X. 
% D = pdist(X,Distance) returns the distance by using the method specified by Distance. 

% Create a matrix with three observations and two variables.

rng('default') % initiating the random number generator

X = rand(10,3); % Create a matrix with 10 observations of 3 variables.

D = pdist(X);  % returns the Euclidean distance between pairs of observations

Z = squareform(D); % locate the distance between observations i and j in the form of a distance matrix

% Draw a dendrogram 

%%%%%%%%%  linkage -- Agglomerative hierarchical cluster tree %%%

%% R = linkage(X) returns a matrix that encodes a tree of hierarchical clusters 
%% of the rows of the real matrix X.

tree = linkage(X,'average');

%%   Method	Description

%%  'average'	Unweighted average distance (UPGMA)

%%  'centroid'	Centroid distance (UPGMC), appropriate for Euclidean distances only

%%  'complete'  Furthest distance 

%%   'median'   Weighted center of mass distance (WPGMC), appropriate for Euclidean distances only

%%   'single' Shortest distance

%%   'ward'   Inner squared distance (minimum variance algorithm),  Euclidean distances only


H = dendrogram(tree,'Orientation','left','ColorThreshold','default');
set(H,'LineWidth',2)

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% 

X = rand(100,3);

%%%%  T = clusterdata(X,cutoff) 

%% clusterdata forms clusters when inconsistent values are greater than cutoff 

T = clusterdata(X,0.1) 

scatter3(X(:,1),X(:,2),X(:,3),100,T,'filled')

scatter3(X(:,1),X(:,2),X(:,3),10,T,'filled')


%% 'Maxclust' Maximum number of clusters to form, a positive integer.

T = clusterdata(X,'Maxclust',3); %% 3 clusters

scatter3(X(:,1),X(:,2),X(:,3),100,T,'filled')

T = clusterdata(X,'Maxclust',5); %% 5 clusters

scatter3(X(:,1),X(:,2),X(:,3),100,T,'filled')

%%%  tree 

tree = linkage(X,'average'); %%


%% plot the dendrogram with only 25 leaf nodes. 

figure
[~,T] = dendrogram(tree,5);

%%%%%%%%%%%%%%%  K-Nearest Neighbors %%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
clear

load fisheriris

rng(1); % For reproducibility

%%% Remove five irises randomly from the predictor data to use as a query set.

n = size(meas,1);
idx = randsample(n,5);

X = meas(~ismember(1:n,idx),:); % Training data
Y = meas(idx,:);                % Query data

%%% Grow a four-dimensional K d-tree using the training data. 
%%  Specify to use the Minkowski distance for finding nearest neighbors later.


Mdl = KDTreeSearcher(X,'Distance','minkowski')

%% Find the indices (of the relevant clusters) of the training data (X) that are the two nearest neighbors 
%%  of each point in the query data (Y).

Idx = knnsearch(Mdl,Y,'K',2)

% Idx =
%
%    17     4
%     6     2
%     1    12
%    89    66
%   124   100

%% Each row of Idx corresponds to a query data observation, 
%% and the column order corresponds to the order of the nearest neighbors, 
%% with respect to ascending distance. 
%% For example, using the Minkowski distance, 
%% the second nearest neighbor of Y(3,:) is X(12,:).



%%%%%%%%%%%%%%%%%   K- MEANS %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

clear

%% kmeans(X,k) performs k-means clustering to partition the observations 
%% of the n-by-p data matrix X into k clusters, and returns an n-by-1 vector 
%% containing cluster indices of each observation.


load fisheriris
X = meas(:,3:4);

figure;
plot(X(:,1),X(:,2),'k*','MarkerSize',5);
title 'Fisher''s Iris Data';
xlabel 'Petal Lengths (cm)'; 
ylabel 'Petal Widths (cm)';

%%%% 
%% rng(1); 

[idx,C] = kmeans(X,3); %%%   Cluster (w.r.t the squared Euclidean distance) the data 
                       %%    into k = 3 clusters; C - centroids coordinates 

%%% idx = is a vector of predicted cluster indices corresponding to the observations in X

%%%  Use kmeans to compute the distance from each centroid to points on a grid. 
%%   To do this, pass the centroids (C) and points on a grid to kmeans, 
%%   and implement one iteration of the algorithm.

x1 = min(X(:,1)):0.01:max(X(:,1));
x2 = min(X(:,2)):0.01:max(X(:,2));
[x1G,x2G] = meshgrid(x1,x2);
XGrid = [x1G(:),x2G(:)]; % Defines a fine grid on the plot

idx2Region = kmeans(XGrid,3,'MaxIter',1,'Start',C); %% Warning: Failed to converge in 1 iterations.


%% Plot the cluster regions.

figure;
gscatter(XGrid(:,1),XGrid(:,2),idx2Region,...
    [0,0.75,0.75;0.75,0,0.75;0.75,0.75,0],'..');
hold on;
plot(X(:,1),X(:,2),'k*','MarkerSize',5);
title 'Fisher''s Iris Data';
xlabel 'Petal Lengths (cm)';
ylabel 'Petal Widths (cm)'; 
legend('Region 1','Region 2','Region 3','Data','Location','SouthEast');
hold off;

%%% Partition Data into Two Clusters
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

rng default; % For reproducibility
X = [randn(100,2)*0.75+ones(100,2);
    randn(100,2)*0.5-ones(100,2)];

figure;
plot(X(:,1),X(:,2),'.');
title 'Randomly Generated Data';

%%% Partition the data into two clusters, 
%%  and choose the best arrangement out of 5 initializations. Display the final output.

opts = statset('Display','final');
[idx,C] = kmeans(X,2,'Distance','cityblock',...
    'Replicates',5,'Options',opts);


%%%%%%%%% Plot the clusters and the cluster centroids.


figure;
plot(X(idx==1,1),X(idx==1,2),'r.','MarkerSize',12)
hold on
plot(X(idx==2,1),X(idx==2,2),'b.','MarkerSize',12)
plot(C(:,1),C(:,2),'kx',...
     'MarkerSize',15,'LineWidth',3) 
legend('Cluster 1','Cluster 2','Centroids',...
       'Location','NW')
title 'Cluster Assignments and Centroids'
hold off

%%%%%%%%%% Create a silhouette plot from the clustered data to determine 
%%        how well separated the clusters are

%%% The silhouette value for each point is a measure of how similar 
%%  that point is to points in its own cluster, when compared to points in other clusters.

% The silhouette value ranges from -1 to +1. A high silhouette value indicates that i is well-matched to 
% its own cluster, and poorly-matched to neighboring clusters. If most points have a high silhouette 
% value, then the clustering solution is appropriate
 

silhouette(X,idx)

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%% Fit a Gaussian Mixture Model
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

clear

%% Generate data from a mixture of two bivariate Gaussian distributions 
%% using the 'mvnrnd' function. Fit to the resulting data.
%% Generate the data using 1000 points from each distribution.

rng(1); % For reproducibility
MU1 = [1 2];
SIGMA1 = [2 0; 0 .5];
MU2 = [-3 -5];
SIGMA2 = [1 0; 0 1];
X = [mvnrnd(MU1,SIGMA1,1000);mvnrnd(MU2,SIGMA2,1000)];

scatter(X(:,1),X(:,2),10,'+')
hold on

%%% Fit a two-component Gaussian mixture model.

options = statset('Display','final');
obj = fitgmdist(X,2,'Options',options);

%%%%%  Plot the fit.

h = ezcontour(@(x,y)pdf(obj,[x y]),[-8 6],[-8 6]);


%%%%%%%%%%%%%%% Select the Number of Gaussian Mixture Model Components Using PCA
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

clear


load fisheriris
classes = unique(species)

%% The data set contains three classes of iris species. 
%% Use principal component analysis to reduce the dimension 
%% of the data to two dimensions for visualization.


[~,score] = pca(meas,'NumComponents',2);


%%%%%%%%% Fit three Gaussian mixture models to the data by specifying 1, 2, and 3 components. 
%%%  the number of optimization iterations = 1000. 

%%% GMModels is a cell array containing three, fitted gmdistribution models. 
%% The means in the three component models are different, suggesting that 
%% the model distinguishes among the three iris species.

GMModels = cell(3,1); % Preallocation
options = statset('MaxIter',1000);
rng(1); % For reproducibility

for j = 1:3
    GMModels{j} = fitgmdist(score,j,'Options',options);
    fprintf('\n GM Mean for %i Component(s)\n',j)
    Mu = GMModels{j}.mu     
end

%%% Fit a two-component Gaussian mixture model.


%%% Plot the scores over the fitted Gaussian mixture model contours. 
%%  Since the data set includes labels, use gscatter to distinguish 
%%  between the true number of components.
 
figure
for j = 1:3
    subplot(2,2,j)
    h1 = gscatter(score(:,1),score(:,2),species);
    h = gca;
    hold on
    ezcontour(@(x1,x2)pdf(GMModels{j},[x1 x2]),...
        [h.XLim h.YLim],100)
    title(sprintf('GM Model - %i Component(s)',j));
    xlabel('1st principal component');
    ylabel('2nd principal component');
    if(j ~= 3)
        legend off;
    end
    hold off
end
g = legend(h1);
g.Position = [0.7 0.25 0.1 0.1];


%%%%%%%%%%%%%%






  