%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%% PageRank Algorithm %%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


%% Create a graph that illustrates how each node confers its 
%% PageRank score to the other nodes in the graph.

s = {'a' 'a' 'a' 'b' 'b' 'c' 'd' 'd' 'd'};
t = {'b' 'c' 'd' 'd' 'a' 'b' 'c' 'a' 'b'};
G = digraph(s,t);
labels = {'a/3' 'a/3' 'a/3' 'b/2' 'b/2' 'c' 'd/3' 'd/3' 'd/3'};
p = plot(G,'Layout','layered','EdgeLabel',labels);
highlight(p,[1 1 1],[2 3 4],'EdgeColor','g')
highlight(p,[2 2],[1 4],'EdgeColor','r')
highlight(p,3,2,'EdgeColor','m')
title('PageRank Score Transfer Between Nodes')

%% The centrality function contains an option for calculating PageRank scores.


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% PageRank with 6 Nodes %%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%% Create and plot a directed graph containing six nodes 
%% representing fictitious websites.

s = [1 1 2 2 3 3 3 4 5];
t = [2 5 3 4 4 5 6 1 1];
names = {'http://www.example.com/alpha', 'http://www.example.com/beta', ...
         'http://www.example.com/gamma', 'http://www.example.com/delta', ...
         'http://www.example.com/epsilon', 'http://www.example.com/zeta'};
G = digraph(s,t,[],names)

plot(G,'Layout','layered', ...
    'NodeLabel',{'alpha','beta','gamma','delta','epsilon','zeta'})


%% Calculate the PageRank centrality score for this graph. 
%% Use a follow probability (otherwise known as a damping factor) of 0.85.

pr = centrality(G,'pagerank','FollowProbability',0.85)

%% View the PageRank scores and degree information for each page.

G.Nodes.PageRank = pr;
G.Nodes.InDegree = indegree(G);
G.Nodes.OutDegree = outdegree(G);
G.Nodes

%%  it is not just the number of page links that determines 
%% the score, but also the quality. The alpha and gamma websites 
%% both have a total degree of 4, however alpha links to both epsilon 
%% and beta, which also are highly ranked. gamma is only linked to by 
%% one page, beta, which is in the middle of the list. 
%% Thus, alpha is scored higher than gamma by the algorithm.


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% PageRank of Websites on mathworks.com
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%% Load the data in mathworks100.mat and view the adjacency matrix, A. 
%% This data was generated in 2015 using an automatic page crawler. 
%% The page crawler began at https://www.mathworks.com and followed links 
%% to subsequent web pages until the adjacency matrix contained information 
%% on the connections of 100 unique web pages.

load mathworks100.mat 
spy(A)

%% Create a directed graph with the sparse adjacency matrix, A, 
%% using the URLs contained in U as node names.

G = digraph(A,U)

plot(G,'NodeLabel',{},'NodeColor',[0.93 0.78 0],'Layout','force');
title('Websites linked to https://www.mathworks.com')


%% Compute the PageRank scores for the graph, G, using 200 iterations 
%% and a damping factor of 0.85. Add the scores and degree information 
%% to the nodes table of the graph.

pr = centrality(G,'pagerank','MaxIterations',200,'FollowProbability',0.85);
G.Nodes.PageRank = pr;
G.Nodes.InDegree = indegree(G);
G.Nodes.OutDegree = outdegree(G);

%% View the top 25 resulting scores.

G.Nodes(1:25,:)

%% Extract and plot a subgraph containing all nodes whose score 
%% is greater than 0.005. 

H = subgraph(G,find(G.Nodes.PageRank > 0.005));
plot(H,'NodeLabel',{},'NodeCData',H.Nodes.PageRank,'Layout','force');
title('Websites linked to https://www.mathworks.com')
colorbar

